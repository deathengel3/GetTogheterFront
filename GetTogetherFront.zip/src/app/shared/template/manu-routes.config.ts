
export const ROUTES: any[] = [
    {
        link: '/',
        label: 'Dashboard',
        icon: 'home',
        items: []
    },
    {
        link: '/home-admin',
        label: 'Admin',
        icon: 'supervisor_account',
        items: []
    },
    {
        link: '/home-user',
        label: 'Usuario',
        icon: 'assignment',
        items: []
    }
];
