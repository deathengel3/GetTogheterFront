export enum Rol{
    Administrador = 1,
    Usuario = 2
}