export class Usuario{
    idEmpleado: number;
    nombre: string;
    rol: number;
    token?: string;
}